# AOSP-Testkey-BootSigner for Android 📱🔐

> **Android 原生端 AOSP Testkey 镜像重签工具** —— 无需电脑、无需 Python 环境，直接在 Android 手机上对 `boot.img`、`init_boot.img`、`vendor_boot.img`、`recovery.img` 进行 AVB 2.0 (Android Verified Boot) 重新签名。

---

## 🌟 特性功能 (Features)

* 🔐 **纯 Kotlin/Java 原生 AVB 签名引擎**：无需依赖外部 Python 或 Root 权限，手机原生快速完成 AVB 2.0 Hash Descriptor 和 VBMeta Footer 计算与签名。
* 🔑 **内置官方 AOSP 公测密钥**：
  * `AOSP testkey_rsa2048.pem` (SHA256_RSA2048)
  * `AOSP testkey_rsa4096.pem` (SHA256_RSA4096 / SHA512_RSA4096)
  * 支持自定义外部 RSA `.pem` 私钥导入。
* 🛡️ **智能签名管理**：
  * 自动检测并识别 Android Boot Header (v0~v4)。
  * 重签时自动检测并剥离旧 AVB Footer，避免多次签名导致镜像体积异常膨胀。
  * 支持一键清除/移除现有签名（Strip AVB）。
* 🎨 **现代 Material 3 极简界面**：
  * 支持 Android SAF 存储访问框架，适配 Android 7.0 ~ Android 14/15/16。
  * 实时终端控制台日志输出与一键复制。
* 🚀 **GitHub Actions CI/CD 开箱即用**：
  * 内置自动化编译脚本，推送到 GitHub 后自动生成并发布 Debug & Release APK。

---

## 🛠️ 项目结构

```
AOSP-Testkey-BootSigner-Android/
├── .github/workflows/build.yml     # GitHub Actions 自动化编译 APK 工作流
├── app/
│   ├── build.gradle.kts            # App 模块构建配置 (Jetpack Compose, Material 3)
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/wjj/bootsigner/
│           ├── MainActivity.kt     # 主入口与 Intent 响应
│           ├── core/               # 核心 AVB 2.0 签名与解析引擎
│           │   ├── AvbConstants.kt
│           │   ├── AvbCrypto.kt    # RSA 密钥与 SHA/RSA 签名
│           │   ├── AvbSignerEngine.kt
│           │   ├── AvbStructs.kt   # Footer / VBMeta / HashDescriptor
│           │   ├── BootImageParser.kt
│           │   └── EmbeddedKeys.kt # 内置公测密钥
│           ├── ui/                 # Material 3 UI 与 ViewModel
│           └── utils/              # 文件与日志工具
├── build.gradle.kts
└── settings.gradle.kts
```

---

## 📦 如何在 GitHub 上编译 APK

1. 将本项目的全部文件上传到您的 GitHub 仓库（例如 `https://github.com/WJJ214453/AOSP-Testkey-BootSigner`）。
2. 进入仓库页面的 **Actions** 标签页。
3. GitHub Actions 将会自动运行 `Build Android APK` 工作流。
4. 构建完成后，在 **Artifacts** 处即可直接下载打包好的 `.apk` 安装包！

---

## 💻 本地编译 (Local Build)

### 环境要求
* JDK 17+
* Android Studio Iguana / Jellyfish / Koala 或更高版本
* Android SDK (API 34)

### 命令行编译
```bash
# 赋予 gradlew 执行权限 (Linux/macOS)
chmod +x gradlew

# 编译 Debug 版 APK
./gradlew assembleDebug

# 编译 Release 版 APK
./gradlew assembleRelease
```
编译产物位于 `app/build/outputs/apk/` 目录下。

---

## 📄 开源许可 (License)
本项目基于 [Apache License 2.0](LICENSE) 协议开源。
