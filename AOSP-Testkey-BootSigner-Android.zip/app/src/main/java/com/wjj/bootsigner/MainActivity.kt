package com.wjj.bootsigner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.wjj.bootsigner.ui.MainScreen
import com.wjj.bootsigner.ui.MainViewModel
import com.wjj.bootsigner.ui.theme.AOSPBootSignerTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Handle external Intent if user opens a .img file with this app
        handleIncomingIntent(intent)

        setContent {
            AOSPBootSignerTheme {
                MainScreen(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let { handleIncomingIntent(it) }
    }

    private fun handleIncomingIntent(intent: Intent) {
        if (intent.action == Intent.ACTION_VIEW) {
            val uri: Uri? = intent.data
            uri?.let {
                viewModel.onFileSelected(this, it)
            }
        }
    }
}
