package com.wjj.bootsigner.ui

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wjj.bootsigner.core.AvbSignerEngine
import com.wjj.bootsigner.core.BootImageInfo
import com.wjj.bootsigner.core.BootImageParser
import com.wjj.bootsigner.core.KeySource
import com.wjj.bootsigner.core.SignAlgorithm
import com.wjj.bootsigner.core.SignConfig
import com.wjj.bootsigner.utils.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MainUiState(
    val selectedUri: Uri? = null,
    val fileName: String = "",
    val fileSizeFormatted: String = "",
    val rawBytes: ByteArray? = null,
    val bootInfo: BootImageInfo? = null,
    val partitionName: String = "boot",
    val keySource: KeySource = KeySource.AOSP_TESTKEY_RSA2048,
    val customPemKey: String = "",
    val algorithm: SignAlgorithm = SignAlgorithm.SHA256_RSA2048,
    val rollbackIndex: Long = 0L,
    val isProcessing: Boolean = false,
    val signedBytes: ByteArray? = null,
    val logs: List<String> = emptyList(),
    val errorMessage: String? = null,
    val successMessage: String? = null
)

class MainViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val dateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun log(message: String) {
        val time = dateFormat.format(Date())
        val logLine = "[$time] $message"
        _uiState.update { it.copy(logs = it.logs + logLine) }
    }

    fun clearLogs() {
        _uiState.update { it.copy(logs = emptyList(), errorMessage = null, successMessage = null) }
    }

    fun onFileSelected(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, errorMessage = null) }
            log("📂 已选择文件: $uri")
            try {
                val (name, size) = FileUtils.getFileNameAndSize(context, uri)
                val bytes = withContext(Dispatchers.IO) {
                    FileUtils.readUriBytes(context, uri)
                }
                val info = BootImageParser.parse(bytes)

                _uiState.update {
                    it.copy(
                        selectedUri = uri,
                        fileName = name,
                        fileSizeFormatted = FileUtils.formatFileSize(size.takeIf { s -> s > 0 } ?: bytes.size.toLong()),
                        rawBytes = bytes,
                        bootInfo = info,
                        isProcessing = false,
                        signedBytes = null
                    )
                }

                log("📊 镜像解析结果: 大小 ${bytes.size} 字节 | 是标准Boot: ${info.isValidBootImage} (Header v${info.headerVersion})")
                if (info.isAvbSigned) {
                    log("🛡️ 已有 AVB 签名: 算法 ${info.algorithmName ?: "未知"} | 防回滚索引 ${info.rollbackIndex ?: 0}")
                } else {
                    log("ℹ️ 镜像当前为 未签名 状态。")
                }
            } catch (e: Exception) {
                log("❌ 加载文件失败: ${e.localizedMessage}")
                _uiState.update { it.copy(isProcessing = false, errorMessage = "读取文件失败: ${e.localizedMessage}") }
            }
        }
    }

    fun setPartitionName(name: String) {
        _uiState.update { it.copy(partitionName = name) }
    }

    fun setKeySource(source: KeySource) {
        _uiState.update {
            it.copy(
                keySource = source,
                algorithm = when (source) {
                    KeySource.AOSP_TESTKEY_RSA2048 -> SignAlgorithm.SHA256_RSA2048
                    KeySource.AOSP_TESTKEY_RSA4096 -> SignAlgorithm.SHA256_RSA4096
                    KeySource.CUSTOM_PEM_KEY -> it.algorithm
                }
            )
        }
    }

    fun setCustomPemKey(pem: String) {
        _uiState.update { it.copy(customPemKey = pem) }
    }

    fun setAlgorithm(algo: SignAlgorithm) {
        _uiState.update { it.copy(algorithm = algo) }
    }

    fun setRollbackIndex(idx: Long) {
        _uiState.update { it.copy(rollbackIndex = idx) }
    }

    fun startSigning() {
        val state = _uiState.value
        val bytes = state.rawBytes ?: run {
            log("⚠️ 请先选择需要签名的 boot.img 镜像文件！")
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, errorMessage = null, successMessage = null) }
            try {
                val config = SignConfig(
                    partitionName = state.partitionName.ifBlank { "boot" },
                    keySource = state.keySource,
                    customPemKey = state.customPemKey,
                    algorithm = state.algorithm,
                    rollbackIndex = state.rollbackIndex
                )

                val signed = withContext(Dispatchers.Default) {
                    AvbSignerEngine.sign(bytes, config) { msg ->
                        log(msg)
                    }
                }

                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        signedBytes = signed,
                        successMessage = "🎉 签名成功！请点击下方【保存签名镜像】导出文件。"
                    )
                }
            } catch (e: Exception) {
                log("❌ 签名失败: ${e.localizedMessage}")
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        errorMessage = "签名出错: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun stripSignature() {
        val state = _uiState.value
        val bytes = state.rawBytes ?: run {
            log("⚠️ 请先选择需要处理的镜像文件！")
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true, errorMessage = null, successMessage = null) }
            try {
                val stripped = withContext(Dispatchers.Default) {
                    AvbSignerEngine.stripFooter(bytes) { msg ->
                        log(msg)
                    }
                }

                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        signedBytes = stripped,
                        successMessage = "✅ 签名移除完成！可保存未签名的原始镜像。"
                    )
                }
            } catch (e: Exception) {
                log("❌ 移除签名失败: ${e.localizedMessage}")
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        errorMessage = "操作失败: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun saveSignedFile(context: Context, targetUri: Uri) {
        val data = _uiState.value.signedBytes ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessing = true) }
            try {
                withContext(Dispatchers.IO) {
                    FileUtils.writeUriBytes(context, targetUri, data)
                }
                log("💾 成功导出文件至: $targetUri (${data.size} 字节)")
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        successMessage = "文件已成功保存！"
                    )
                }
            } catch (e: Exception) {
                log("❌ 保存文件失败: ${e.localizedMessage}")
                _uiState.update {
                    it.copy(
                        isProcessing = false,
                        errorMessage = "保存失败: ${e.localizedMessage}"
                    )
                }
            }
        }
    }
}
