package com.wjj.bootsigner.core

import android.util.Base64
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.interfaces.RSAPrivateCrtKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.RSAPublicKeySpec

object AvbCrypto {

    fun calculateHash(data: ByteArray, algorithm: String = "SHA-256"): ByteArray {
        val digest = MessageDigest.getInstance(algorithm)
        return digest.digest(data)
    }

    /**
     * Compute n0inv = -(n0^-1) mod 2^32 where n0 = modulus mod 2^32.
     * Uses Newton-Raphson iteration for modular inverse.
     */
    fun computeN0Inv(modulus: BigInteger): Long {
        val mask32 = BigInteger.valueOf(0xFFFFFFFFL)
        val n0 = modulus.and(mask32).toLong()
        var x = 1L
        for (i in 0 until 6) {
            x = (x * (2L - (n0 and 0xFFFFFFFFL) * x)) and 0xFFFFFFFFL
        }
        val n0inv = ((-x) and 0xFFFFFFFFL)
        return n0inv
    }

    /**
     * Encodes RSA Public Key according to libavb AvbRSAPublicKey format.
     */
    fun encodeAvbRSAPublicKey(publicKey: RSAPublicKey): ByteArray {
        val numBits = publicKey.modulus.bitLength()
        val keyBytes = numBits / 8
        val n = publicKey.modulus
        val n0inv = computeN0Inv(n)

        // Compute r = 2^numBits, rr = (r^2) mod n
        val r = BigInteger.ONE.shiftLeft(numBits)
        val rr = r.multiply(r).mod(n)

        val buffer = ByteBuffer.allocate(8 + keyBytes + keyBytes)
        buffer.order(ByteOrder.BIG_ENDIAN)

        // AvbRSAPublicKeyHeader (8 bytes)
        buffer.putInt(numBits)
        buffer.putInt(n0inv.toInt())

        // Modulus (keyBytes)
        val nBytes = toFixedLengthByteArray(n, keyBytes)
        buffer.put(nBytes)

        // rr (keyBytes)
        val rrBytes = toFixedLengthByteArray(rr, keyBytes)
        buffer.put(rrBytes)

        return buffer.array()
    }

    private fun toFixedLengthByteArray(value: BigInteger, length: Int): ByteArray {
        val raw = value.toByteArray()
        val result = ByteArray(length)
        if (raw.size == length) {
            System.arraycopy(raw, 0, result, 0, length)
        } else if (raw.size > length) {
            // Drop leading sign byte
            System.arraycopy(raw, raw.size - length, result, 0, length)
        } else {
            // Pad leading zeros
            System.arraycopy(raw, 0, result, length - raw.size, raw.size)
        }
        return result
    }

    /**
     * Signs data using the specified RSA private key and algorithm.
     */
    fun sign(data: ByteArray, privateKey: PrivateKey, algorithm: SignAlgorithm): ByteArray {
        val sigAlgo = when (algorithm) {
            SignAlgorithm.SHA256_RSA2048, SignAlgorithm.SHA256_RSA4096 -> "SHA256withRSA"
            SignAlgorithm.SHA512_RSA4096 -> "SHA512withRSA"
        }
        val signer = Signature.getInstance(sigAlgo)
        signer.initSign(privateKey)
        signer.update(data)
        return signer.sign()
    }

    /**
     * Derives RSAPublicKey from an RSAPrivateCrtKey.
     */
    fun getPublicKey(privateKey: RSAPrivateCrtKey): RSAPublicKey {
        val spec = RSAPublicKeySpec(privateKey.modulus, privateKey.publicExponent)
        val kf = KeyFactory.getInstance("RSA")
        return kf.generatePublic(spec) as RSAPublicKey
    }

    /**
     * Parses a PEM private key string (supports both PKCS#8 and PKCS#1).
     */
    fun parsePrivateKey(pem: String): RSAPrivateCrtKey {
        val cleanPem = pem.replace("-----BEGIN RSA PRIVATE KEY-----", "")
            .replace("-----END RSA PRIVATE KEY-----", "")
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replace("\\s".toRegex(), "")

        val der = Base64.decode(cleanPem, Base64.DEFAULT)

        val kf = KeyFactory.getInstance("RSA")

        return try {
            // Try standard PKCS#8 first
            val spec = PKCS8EncodedKeySpec(der)
            kf.generatePrivate(spec) as RSAPrivateCrtKey
        } catch (e: Exception) {
            // Wrap PKCS#1 into PKCS#8
            val pkcs8Der = wrapPkcs1ToPkcs8(der)
            val spec = PKCS8EncodedKeySpec(pkcs8Der)
            kf.generatePrivate(spec) as RSAPrivateCrtKey
        }
    }

    private fun wrapPkcs1ToPkcs8(pkcs1Der: ByteArray): ByteArray {
        // ASN.1 PKCS#8 structure prefix for RSA:
        // SEQUENCE (length)
        //   INTEGER 0 (version)
        //   SEQUENCE (AlgorithmIdentifier rsaEncryption)
        //     OID 1.2.840.113549.1.1.1
        //     NULL
        //   OCTET STRING (pkcs1 bytes)
        val rsaOid = byteArrayOf(
            0x30.toByte(), 0x0d.toByte(),
            0x06.toByte(), 0x09.toByte(), 0x2a.toByte(), 0x86.toByte(), 0x48.toByte(),
            0x86.toByte(), 0xf7.toByte(), 0x0d.toByte(), 0x01.toByte(), 0x01.toByte(), 0x01.toByte(),
            0x05.toByte(), 0x00.toByte()
        )

        val octetHeader = encodeAsn1Length(0x04, pkcs1Der.size)
        val innerSeqLen = 3 + rsaOid.size + octetHeader.size + pkcs1Der.size
        val seqHeader = encodeAsn1Length(0x30, innerSeqLen)

        val buffer = ByteBuffer.allocate(seqHeader.size + 3 + rsaOid.size + octetHeader.size + pkcs1Der.size)
        buffer.put(seqHeader)
        buffer.put(byteArrayOf(0x02, 0x01, 0x00)) // version 0
        buffer.put(rsaOid)
        buffer.put(octetHeader)
        buffer.put(pkcs1Der)
        return buffer.array()
    }

    private fun encodeAsn1Length(tag: Int, length: Int): ByteArray {
        return if (length < 128) {
            byteArrayOf(tag.toByte(), length.toByte())
        } else if (length < 256) {
            byteArrayOf(tag.toByte(), 0x81.toByte(), length.toByte())
        } else if (length < 65536) {
            byteArrayOf(tag.toByte(), 0x82.toByte(), (length shr 8).toByte(), (length and 0xff).toByte())
        } else {
            byteArrayOf(
                tag.toByte(), 0x83.toByte(),
                (length shr 16).toByte(), ((length shr 8) and 0xff).toByte(), (length and 0xff).toByte()
            )
        }
    }
}
