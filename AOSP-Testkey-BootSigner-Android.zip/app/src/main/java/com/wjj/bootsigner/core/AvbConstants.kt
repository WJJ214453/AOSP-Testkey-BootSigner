package com.wjj.bootsigner.core

object AvbConstants {
    const val AVB_MAGIC_FOOTER = "AVBf"
    const val AVB_MAGIC_VBMETA = "AVB0"
    const val BOOT_MAGIC = "ANDROID!"

    const val AVB_FOOTER_SIZE = 64
    const val AVB_VBMETA_HEADER_SIZE = 256
    const val AVB_DESCRIPTOR_TAG_HASH = 2L

    // Algorithm Types defined in AOSP libavb
    const val AVB_ALGORITHM_TYPE_NONE = 0
    const val AVB_ALGORITHM_TYPE_SHA256_RSA2048 = 1
    const val AVB_ALGORITHM_TYPE_SHA256_RSA4096 = 2
    const val AVB_ALGORITHM_TYPE_SHA256_RSA8192 = 3
    const val AVB_ALGORITHM_TYPE_SHA512_RSA2048 = 4
    const val AVB_ALGORITHM_TYPE_SHA512_RSA4096 = 5
    const val AVB_ALGORITHM_TYPE_SHA512_RSA8192 = 6

    const val AVB_RELEASE_STRING = "avbtool 1.2.0 (AOSP BootSigner Android)"

    const val DEFAULT_ALIGNMENT = 4096
}

enum class SignAlgorithm(val displayName: String, val typeId: Int, val rsaBits: Int, val hashAlgorithm: String) {
    SHA256_RSA2048("SHA256_RSA2048", AvbConstants.AVB_ALGORITHM_TYPE_SHA256_RSA2048, 2048, "SHA-256"),
    SHA256_RSA4096("SHA256_RSA4096", AvbConstants.AVB_ALGORITHM_TYPE_SHA256_RSA4096, 4096, "SHA-256"),
    SHA512_RSA4096("SHA512_RSA4096", AvbConstants.AVB_ALGORITHM_TYPE_SHA512_RSA4096, 4096, "SHA-512")
}

enum class KeySource(val displayName: String) {
    AOSP_TESTKEY_RSA2048("AOSP 公测密钥 (RSA-2048)"),
    AOSP_TESTKEY_RSA4096("AOSP 公测密钥 (RSA-4096)"),
    CUSTOM_PEM_KEY("自定义私钥 (.pem)")
}
