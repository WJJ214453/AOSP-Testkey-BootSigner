package com.wjj.bootsigner.core

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class SignConfig(
    val partitionName: String = "boot",
    val keySource: KeySource = KeySource.AOSP_TESTKEY_RSA2048,
    val customPemKey: String = "",
    val algorithm: SignAlgorithm = SignAlgorithm.SHA256_RSA2048,
    val rollbackIndex: Long = 0L,
    val flags: Int = 0,
    val alignBoundary: Int = AvbConstants.DEFAULT_ALIGNMENT
)

object AvbSignerEngine {

    fun sign(sourceBytes: ByteArray, config: SignConfig, onLog: (String) -> Unit): ByteArray {
        onLog("🚀 开始执行 AVB 签名流程...")
        onLog("📦 目标分区: [${config.partitionName}]")
        onLog("⚙️ 签名算法: ${config.algorithm.displayName} | 防回滚索引: ${config.rollbackIndex}")

        // 1. 检查并剥离已有 AVB Footer
        val parsed = BootImageParser.parse(sourceBytes)
        val cleanBytes: ByteArray
        if (parsed.isAvbSigned) {
            onLog("⚠️ 检测到文件已存在 AVB Footer，正在自动剥离旧签名...")
            cleanBytes = ByteArray(parsed.originalSize.toInt())
            System.arraycopy(sourceBytes, 0, cleanBytes, 0, parsed.originalSize.toInt())
            onLog("✅ 旧签名已剥离，原始镜像大小: ${cleanBytes.size} 字节")
        } else {
            cleanBytes = sourceBytes
            onLog("ℹ️ 文件为未签名状态，大小: ${cleanBytes.size} 字节")
        }

        if (cleanBytes.isEmpty()) {
            throw IllegalArgumentException("输入镜像数据为空！")
        }

        // 2. 加载私钥与公钥
        val pemString = when (config.keySource) {
            KeySource.AOSP_TESTKEY_RSA2048 -> EmbeddedKeys.AOSP_TESTKEY_RSA2048
            KeySource.AOSP_TESTKEY_RSA4096 -> EmbeddedKeys.AOSP_TESTKEY_RSA4096
            KeySource.CUSTOM_PEM_KEY -> {
                if (config.customPemKey.isBlank()) {
                    throw IllegalArgumentException("自定义私钥内容为空！请提供有效的 PEM 格式 RSA 私钥。")
                }
                config.customPemKey
            }
        }
        onLog("🔑 正在解析并加载 RSA 私钥...")
        val privateKey = AvbCrypto.parsePrivateKey(pemString)
        val publicKey = AvbCrypto.getPublicKey(privateKey)
        onLog("✅ RSA 密钥加载成功: 模长 ${publicKey.modulus.bitLength()} bits")

        // 3. 计算镜像 Hash 并生成 Hash Descriptor
        onLog("🔍 正在计算镜像 ${config.algorithm.hashAlgorithm} 哈希摘要...")
        val imageDigest = AvbCrypto.calculateHash(cleanBytes, config.algorithm.hashAlgorithm)
        val hashDescriptor = AvbHashDescriptor(
            imageSize = cleanBytes.size.toLong(),
            digest = imageDigest,
            partitionName = config.partitionName,
            hashAlgorithm = if (config.algorithm.hashAlgorithm == "SHA-512") "sha512" else "sha256"
        )
        val descBytes = hashDescriptor.serialize()
        onLog("📝 Hash 描述符生成完成，大小: ${descBytes.size} 字节")

        // 4. 编码 AvbRSAPublicKey
        val pubKeyBytes = AvbCrypto.encodeAvbRSAPublicKey(publicKey)

        // 5. 组装 Auxiliary Data Block (PublicKey + Descriptors -> 64-byte padded)
        val auxStream = ByteArrayOutputStream()
        auxStream.write(pubKeyBytes)
        auxStream.write(descBytes)
        val rawAuxBytes = auxStream.toByteArray()
        val auxPaddedSize = padToMultiple(rawAuxBytes.size, 64)
        val auxDataBlock = ByteArray(auxPaddedSize)
        System.arraycopy(rawAuxBytes, 0, auxDataBlock, 0, rawAuxBytes.size)

        // 6. 配置 Authentication Block 参数
        val hashSize = if (config.algorithm.hashAlgorithm == "SHA-512") 64L else 32L
        val sigSize = (config.algorithm.rsaBits / 8).toLong()
        val authDataBlockRawSize = (hashSize + sigSize).toInt()
        val authDataBlockSize = padToMultiple(authDataBlockRawSize, 64)

        // 7. 构建 VBMeta Header
        val vbmetaHeader = AvbVBMetaHeader(
            requiredLibavbVersionMajor = 1,
            requiredLibavbVersionMinor = 0,
            authenticationDataBlockSize = authDataBlockSize.toLong(),
            auxiliaryDataBlockSize = auxDataBlock.size.toLong(),
            algorithmType = config.algorithm.typeId,
            hashOffset = 0L,
            hashSize = hashSize,
            signatureOffset = hashSize,
            signatureSize = sigSize,
            publicKeyOffset = 0L,
            publicKeySize = pubKeyBytes.size.toLong(),
            publicKeyMetadataOffset = 0L,
            publicKeyMetadataSize = 0L,
            descriptorsOffset = pubKeyBytes.size.toLong(),
            descriptorsSize = descBytes.size.toLong(),
            rollbackIndex = config.rollbackIndex,
            flags = config.flags,
            rollbackIndexLocation = 0
        )
        val headerBytes = vbmetaHeader.serialize()

        // 8. 计算 VBMeta 校验 Hash 并签名
        onLog("✍️ 正在计算 VBMeta 签名并生成 Authentication Block...")
        val dataToSign = ByteArray(headerBytes.size + auxDataBlock.size)
        System.arraycopy(headerBytes, 0, dataToSign, 0, headerBytes.size)
        System.arraycopy(auxDataBlock, 0, dataToSign, headerBytes.size, auxDataBlock.size)

        val headerAuxDigest = AvbCrypto.calculateHash(dataToSign, config.algorithm.hashAlgorithm)
        val signatureBytes = AvbCrypto.sign(headerAuxDigest, privateKey, config.algorithm)

        val authBlock = ByteArray(authDataBlockSize)
        System.arraycopy(headerAuxDigest, 0, authBlock, 0, headerAuxDigest.size)
        System.arraycopy(signatureBytes, 0, authBlock, headerAuxDigest.size, signatureBytes.size)

        // 9. 组装完整 VBMeta Image
        val vbmetaImage = ByteArray(headerBytes.size + authBlock.size + auxDataBlock.size)
        System.arraycopy(headerBytes, 0, vbmetaImage, 0, headerBytes.size)
        System.arraycopy(authBlock, 0, vbmetaImage, headerBytes.size, authBlock.size)
        System.arraycopy(auxDataBlock, 0, vbmetaImage, headerBytes.size + authBlock.size, auxDataBlock.size)

        onLog("🧩 VBMeta 数据块组装完成，大小: ${vbmetaImage.size} 字节")

        // 10. 计算偏移量与对齐
        val origSize = cleanBytes.size.toLong()
        val vbmetaOffset = padToMultiple(cleanBytes.size, config.alignBoundary).toLong()
        val vbmetaSize = vbmetaImage.size.toLong()

        val footer = AvbFooter(
            versionMajor = 1,
            versionMinor = 2,
            originalImageSize = origSize,
            vbmetaOffset = vbmetaOffset,
            vbmetaSize = vbmetaSize
        )
        val footerBytes = footer.serialize()

        // 11. 最终拼装 Boot 镜像
        val totalWithoutFooter = (vbmetaOffset + vbmetaSize).toInt()
        val finalTotalSize = padToMultiple(totalWithoutFooter + AvbConstants.AVB_FOOTER_SIZE, config.alignBoundary)

        val finalImage = ByteArray(finalTotalSize)
        // 写入原始镜像
        System.arraycopy(cleanBytes, 0, finalImage, 0, cleanBytes.size)
        // 写入 VBMeta Image
        System.arraycopy(vbmetaImage, 0, finalImage, vbmetaOffset.toInt(), vbmetaImage.size)
        // 写入 Footer 到末尾
        val footerTargetOffset = finalTotalSize - AvbConstants.AVB_FOOTER_SIZE
        System.arraycopy(footerBytes, 0, finalImage, footerTargetOffset, footerBytes.size)

        onLog("🎉 AVB 2.0 签名构建成功！")
        onLog("📊 原始大小: $origSize 字节 | VBMeta 偏移: $vbmetaOffset | 最终大小: $finalTotalSize 字节")
        return finalImage
    }

    fun stripFooter(sourceBytes: ByteArray, onLog: (String) -> Unit): ByteArray {
        onLog("✂️ 正在检查 AVB Footer...")
        val parsed = BootImageParser.parse(sourceBytes)
        if (!parsed.isAvbSigned) {
            onLog("ℹ️ 未发现 AVB Footer，无需剥离。")
            return sourceBytes
        }
        val cleanSize = parsed.originalSize.toInt()
        val result = ByteArray(cleanSize)
        System.arraycopy(sourceBytes, 0, result, 0, cleanSize)
        onLog("✅ 成功移除 AVB 签名！大小由 ${sourceBytes.size} 恢复为 $cleanSize 字节。")
        return result
    }

    private fun padToMultiple(size: Int, alignment: Int): Int {
        val remainder = size % alignment
        return if (remainder == 0) size else size + (alignment - remainder)
    }
}
