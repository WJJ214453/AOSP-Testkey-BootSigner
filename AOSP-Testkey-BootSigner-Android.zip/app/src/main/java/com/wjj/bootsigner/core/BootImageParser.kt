package com.wjj.bootsigner.core

import java.nio.ByteBuffer
import java.nio.ByteOrder

data class BootImageInfo(
    val isValidBootImage: Boolean,
    val headerVersion: Int,
    val kernelSize: Long,
    val ramdiskSize: Long,
    val pageSize: Int,
    val isAvbSigned: Boolean,
    val originalSize: Long,
    val vbmetaOffset: Long,
    val vbmetaSize: Long,
    val algorithmName: String?,
    val rollbackIndex: Long?,
    val rawFileSize: Long
)

object BootImageParser {

    fun parse(data: ByteArray): BootImageInfo {
        val totalSize = data.size.toLong()
        var isValidBoot = false
        var headerVersion = -1
        var kernelSize = 0L
        var ramdiskSize = 0L
        var pageSize = 2048

        // Check ANDROID! magic at offset 0
        if (data.size >= 8) {
            val magic = String(data, 0, 8, Charsets.US_ASCII)
            if (magic == AvbConstants.BOOT_MAGIC) {
                isValidBoot = true
                if (data.size >= 48) {
                    val buffer = ByteBuffer.wrap(data, 8, 40)
                    buffer.order(ByteOrder.LITTLE_ENDIAN)
                    kernelSize = buffer.int.toLong() and 0xFFFFFFFFL
                    buffer.int // kernel_addr
                    ramdiskSize = buffer.int.toLong() and 0xFFFFFFFFL
                    buffer.int // ramdisk_addr
                    buffer.int // second_size
                    buffer.int // second_addr
                    buffer.int // tags_addr
                    pageSize = buffer.int
                    headerVersion = buffer.int
                }
            }
        }

        // Check AVB Footer at end of file (last 64 bytes)
        var isAvbSigned = false
        var origSize = totalSize
        var vbOffset = 0L
        var vbSize = 0L
        var algoName: String? = null
        var rollbackIdx: Long? = null

        if (data.size >= AvbConstants.AVB_FOOTER_SIZE) {
            val footerOffset = data.size - AvbConstants.AVB_FOOTER_SIZE
            val footer = AvbFooter.parse(data, footerOffset)
            if (footer != null) {
                isAvbSigned = true
                origSize = footer.originalImageSize
                vbOffset = footer.vbmetaOffset
                vbSize = footer.vbmetaSize

                // Try to parse VBMeta header at vbmetaOffset
                if (vbOffset >= 0 && vbOffset + AvbConstants.AVB_VBMETA_HEADER_SIZE <= data.size) {
                    val vbMagic = String(data, vbOffset.toInt(), 4, Charsets.US_ASCII)
                    if (vbMagic == AvbConstants.AVB_MAGIC_VBMETA) {
                        val vbBuffer = ByteBuffer.wrap(data, vbOffset.toInt() + 4, AvbConstants.AVB_VBMETA_HEADER_SIZE - 4)
                        vbBuffer.order(ByteOrder.BIG_ENDIAN)
                        vbBuffer.int // req vMaj
                        vbBuffer.int // req vMin
                        vbBuffer.long // auth size
                        vbBuffer.long // aux size
                        val algoType = vbBuffer.int
                        algoName = when (algoType) {
                            AvbConstants.AVB_ALGORITHM_TYPE_SHA256_RSA2048 -> "SHA256_RSA2048"
                            AvbConstants.AVB_ALGORITHM_TYPE_SHA256_RSA4096 -> "SHA256_RSA4096"
                            AvbConstants.AVB_ALGORITHM_TYPE_SHA512_RSA4096 -> "SHA512_RSA4096"
                            else -> "Type #$algoType"
                        }
                        vbBuffer.long // hash offset
                        vbBuffer.long // hash size
                        vbBuffer.long // sig offset
                        vbBuffer.long // sig size
                        vbBuffer.long // pubkey offset
                        vbBuffer.long // pubkey size
                        vbBuffer.long // pubkey meta offset
                        vbBuffer.long // pubkey meta size
                        vbBuffer.long // desc offset
                        vbBuffer.long // desc size
                        rollbackIdx = vbBuffer.long
                    }
                }
            }
        }

        return BootImageInfo(
            isValidBootImage = isValidBoot,
            headerVersion = headerVersion,
            kernelSize = kernelSize,
            ramdiskSize = ramdiskSize,
            pageSize = pageSize,
            isAvbSigned = isAvbSigned,
            originalSize = origSize,
            vbmetaOffset = vbOffset,
            vbmetaSize = vbSize,
            algorithmName = algoName,
            rollbackIndex = rollbackIdx,
            rawFileSize = totalSize
        )
    }
}
