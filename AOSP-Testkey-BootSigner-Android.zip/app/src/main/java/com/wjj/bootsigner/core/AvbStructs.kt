package com.wjj.bootsigner.core

import java.nio.ByteBuffer
import java.nio.ByteOrder

data class AvbFooter(
    val versionMajor: Int = 1,
    val versionMinor: Int = 2,
    val originalImageSize: Long,
    val vbmetaOffset: Long,
    val vbmetaSize: Long
) {
    fun serialize(): ByteArray {
        val buffer = ByteBuffer.allocate(AvbConstants.AVB_FOOTER_SIZE)
        buffer.order(ByteOrder.BIG_ENDIAN)
        buffer.put(AvbConstants.AVB_MAGIC_FOOTER.toByteArray(Charsets.US_ASCII)) // 4 bytes
        buffer.putInt(versionMajor) // 4 bytes
        buffer.putInt(versionMinor) // 4 bytes
        buffer.putLong(originalImageSize) // 8 bytes
        buffer.putLong(vbmetaOffset) // 8 bytes
        buffer.putLong(vbmetaSize) // 8 bytes
        buffer.put(ByteArray(28)) // 28 bytes reserved
        return buffer.array()
    }

    companion object {
        fun parse(data: ByteArray, offset: Int): AvbFooter? {
            if (data.size < offset + AvbConstants.AVB_FOOTER_SIZE) return null
            val magic = String(data, offset, 4, Charsets.US_ASCII)
            if (magic != AvbConstants.AVB_MAGIC_FOOTER) return null

            val buffer = ByteBuffer.wrap(data, offset + 4, AvbConstants.AVB_FOOTER_SIZE - 4)
            buffer.order(ByteOrder.BIG_ENDIAN)
            val vMaj = buffer.int
            val vMin = buffer.int
            val origSize = buffer.long
            val vbOffset = buffer.long
            val vbSize = buffer.long
            return AvbFooter(vMaj, vMin, origSize, vbOffset, vbSize)
        }
    }
}

data class AvbVBMetaHeader(
    val requiredLibavbVersionMajor: Int = 1,
    val requiredLibavbVersionMinor: Int = 0,
    val authenticationDataBlockSize: Long,
    val auxiliaryDataBlockSize: Long,
    val algorithmType: Int,
    val hashOffset: Long = 0,
    val hashSize: Long,
    val signatureOffset: Long,
    val signatureSize: Long,
    val publicKeyOffset: Long = 0,
    val publicKeySize: Long,
    val publicKeyMetadataOffset: Long = 0,
    val publicKeyMetadataSize: Long = 0,
    val descriptorsOffset: Long,
    val descriptorsSize: Long,
    val rollbackIndex: Long = 0,
    val flags: Int = 0,
    val rollbackIndexLocation: Int = 0,
    val releaseString: String = AvbConstants.AVB_RELEASE_STRING
) {
    fun serialize(): ByteArray {
        val buffer = ByteBuffer.allocate(AvbConstants.AVB_VBMETA_HEADER_SIZE)
        buffer.order(ByteOrder.BIG_ENDIAN)
        buffer.put(AvbConstants.AVB_MAGIC_VBMETA.toByteArray(Charsets.US_ASCII)) // 4
        buffer.putInt(requiredLibavbVersionMajor) // 4
        buffer.putInt(requiredLibavbVersionMinor) // 4
        buffer.putLong(authenticationDataBlockSize) // 8
        buffer.putLong(auxiliaryDataBlockSize) // 8
        buffer.putInt(algorithmType) // 4
        buffer.putLong(hashOffset) // 8
        buffer.putLong(hashSize) // 8
        buffer.putLong(signatureOffset) // 8
        buffer.putLong(signatureSize) // 8
        buffer.putLong(publicKeyOffset) // 8
        buffer.putLong(publicKeySize) // 8
        buffer.putLong(publicKeyMetadataOffset) // 8
        buffer.putLong(publicKeyMetadataSize) // 8
        buffer.putLong(descriptorsOffset) // 8
        buffer.putLong(descriptorsSize) // 8
        buffer.putLong(rollbackIndex) // 8
        buffer.putInt(flags) // 4
        buffer.putInt(rollbackIndexLocation) // 4

        // Release string: 48 bytes
        val relBytes = releaseString.toByteArray(Charsets.US_ASCII)
        val relPadded = ByteArray(48)
        System.arraycopy(relBytes, 0, relPadded, 0, minOf(relBytes.size, 47))
        buffer.put(relPadded)

        // Reserved: 80 bytes
        buffer.put(ByteArray(80))

        return buffer.array()
    }
}

class AvbHashDescriptor(
    val imageSize: Long,
    val digest: ByteArray,
    val partitionName: String,
    val hashAlgorithm: String = "sha256",
    val salt: ByteArray = ByteArray(0)
) {
    fun serialize(): ByteArray {
        val partNameBytes = partitionName.toByteArray(Charsets.UTF_8)
        val partNameLen = partNameBytes.size
        val digestLen = digest.size
        val saltLen = salt.size

        // Fixed size = 16 (AvbDescriptor) + 56 = 72 bytes
        val descFixedSize = 72
        val varSize = partNameLen + saltLen + digestLen
        val descSize = descFixedSize + varSize
        val padLen = (8 - (descSize % 8)) % 8
        val totalDescLen = descSize + padLen
        val numBytesFollowing = (totalDescLen - 16).toLong()

        val buffer = ByteBuffer.allocate(totalDescLen)
        buffer.order(ByteOrder.BIG_ENDIAN)

        // Descriptor header (16 bytes)
        buffer.putLong(AvbConstants.AVB_DESCRIPTOR_TAG_HASH)
        buffer.putLong(numBytesFollowing)

        // Hash descriptor fields (56 bytes)
        buffer.putLong(imageSize)
        buffer.putInt(digestLen)
        buffer.putLong((partNameLen + saltLen).toLong()) // digest_offset
        buffer.putInt(saltLen)
        buffer.putLong(partNameLen.toLong()) // salt_offset

        val algoPadded = ByteArray(32)
        val algoBytes = hashAlgorithm.toByteArray(Charsets.US_ASCII)
        System.arraycopy(algoBytes, 0, algoPadded, 0, minOf(algoBytes.size, 31))
        buffer.put(algoPadded)

        buffer.putInt(partNameLen)
        buffer.putLong(0L) // partition_name_offset

        // Variable data: partition name + salt + digest
        buffer.put(partNameBytes)
        if (saltLen > 0) {
            buffer.put(salt)
        }
        buffer.put(digest)

        // Padding
        if (padLen > 0) {
            buffer.put(ByteArray(padLen))
        }

        return buffer.array()
    }
}
