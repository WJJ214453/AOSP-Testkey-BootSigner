package com.wjj.bootsigner.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wjj.bootsigner.core.KeySource
import com.wjj.bootsigner.core.SignAlgorithm
import com.wjj.bootsigner.ui.theme.SuccessGreen
import com.wjj.bootsigner.ui.theme.WarningYellow
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // SAF file picker launchers
    val pickFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.onFileSelected(context, it) }
    }

    val saveFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        uri?.let { viewModel.saveSignedFile(context, it) }
    }

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "AOSP BootSigner",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Text(
                            text = "Android AVB 2.0 镜像重签工具",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.clearLogs() }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "清空日志")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. File Selection Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("镜像文件选择", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    }

                    if (uiState.fileName.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("📄 文件名: ${uiState.fileName}", fontWeight = FontWeight.Medium)
                            Text("📦 文件大小: ${uiState.fileSizeFormatted}", color = MaterialTheme.colorScheme.onSurfaceVariant)

                            uiState.bootInfo?.let { info ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                                    Surface(
                                        color = if (info.isValidBootImage) SuccessGreen.copy(alpha = 0.15f) else WarningYellow.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (info.isValidBootImage) "标准 Boot v${info.headerVersion}" else "原始二进制镜像",
                                            color = if (info.isValidBootImage) SuccessGreen else WarningYellow,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    Surface(
                                        color = if (info.isAvbSigned) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = if (info.isAvbSigned) "AVB已签名 (${info.algorithmName})" else "AVB未签名",
                                            color = if (info.isAvbSigned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Button(
                        onClick = { pickFileLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !uiState.isProcessing
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (uiState.fileName.isEmpty()) "选择 boot.img 镜像" else "更换镜像文件")
                    }
                }
            }

            // 2. Signing Configuration Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("签名参数设置", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    }

                    // Target Partition
                    OutlinedTextField(
                        value = uiState.partitionName,
                        onValueChange = { viewModel.setPartitionName(it) },
                        label = { Text("目标分区名 (Partition Name)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Partition quick chips
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("boot", "init_boot", "vendor_boot", "recovery", "dtbo").forEach { part ->
                            FilterChip(
                                selected = uiState.partitionName == part,
                                onClick = { viewModel.setPartitionName(part) },
                                label = { Text(part) }
                            )
                        }
                    }

                    // Key Source Selection
                    Text("签名密钥类型:", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        KeySource.values().forEach { source ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RadioButton(
                                    selected = uiState.keySource == source,
                                    onClick = { viewModel.setKeySource(source) }
                                )
                                Text(
                                    text = source.displayName,
                                    modifier = Modifier.padding(start = 4.dp),
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }

                    // Custom PEM key input
                    if (uiState.keySource == KeySource.CUSTOM_PEM_KEY) {
                        OutlinedTextField(
                            value = uiState.customPemKey,
                            onValueChange = { viewModel.setCustomPemKey(it) },
                            label = { Text("粘贴 PEM 格式 RSA 私钥") },
                            placeholder = { Text("-----BEGIN RSA PRIVATE KEY-----\n...") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3,
                            maxLines = 6
                        )
                    }

                    // Algorithm Selection
                    Text("签名算法 (Algorithm):", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SignAlgorithm.values().forEach { algo ->
                            FilterChip(
                                selected = uiState.algorithm == algo,
                                onClick = { viewModel.setAlgorithm(algo) },
                                label = { Text(algo.displayName) }
                            )
                        }
                    }

                    // Rollback Index
                    OutlinedTextField(
                        value = uiState.rollbackIndex.toString(),
                        onValueChange = { str ->
                            val num = str.filter { it.isDigit() }.toLongOrNull() ?: 0L
                            viewModel.setRollbackIndex(num)
                        },
                        label = { Text("防回滚索引 (Rollback Index)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }

            // 3. Action Buttons
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { viewModel.startSigning() },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = uiState.rawBytes != null && !uiState.isProcessing,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    if (uiState.isProcessing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("正在处理中...")
                    } else {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("一键使用 AOSP Testkey 签名", fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.stripSignature() },
                        modifier = Modifier.weight(1f),
                        enabled = uiState.rawBytes != null && !uiState.isProcessing
                    ) {
                        Icon(Icons.Default.ContentCut, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("移除现有签名")
                    }

                    FilledTonalButton(
                        onClick = {
                            val defaultName = if (uiState.fileName.isNotEmpty()) {
                                "signed_${uiState.fileName}"
                            } else "signed_boot.img"
                            saveFileLauncher.launch(defaultName)
                        },
                        modifier = Modifier.weight(1f),
                        enabled = uiState.signedBytes != null && !uiState.isProcessing
                    ) {
                        Icon(Icons.Default.SaveAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("保存导出镜像")
                    }
                }
            }

            // Error & Success Feedback
            uiState.errorMessage?.let { err ->
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = err,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(12.dp),
                        fontSize = 14.sp
                    )
                }
            }

            uiState.successMessage?.let { msg ->
                Surface(
                    color = SuccessGreen.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = msg,
                        color = SuccessGreen,
                        modifier = Modifier.padding(12.dp),
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                }
            }

            // 4. Real-time Console Log Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = Color(0xFF64B5F6), modifier = Modifier.size(18.dp))
                            Text("运行控制台日志", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        IconButton(
                            onClick = {
                                val fullLog = uiState.logs.joinToString("\n")
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("BootSigner Log", fullLog))
                                Toast.makeText(context, "日志已复制到剪贴板", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "复制日志", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 100.dp, max = 220.dp)
                            .background(Color(0xFF121214), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        if (uiState.logs.isEmpty()) {
                            Text(
                                text = "等待选择镜像文件...",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        } else {
                            uiState.logs.forEach { line ->
                                Text(
                                    text = line,
                                    color = if (line.contains("❌") || line.contains("失败")) Color(0xFFFF6B6B)
                                    else if (line.contains("✅") || line.contains("🎉")) Color(0xFF69F0AE)
                                    else Color(0xFFECEFF1),
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
