# Proguard rules for AOSP BootSigner
-keep class com.wjj.bootsigner.core.** { *; }
